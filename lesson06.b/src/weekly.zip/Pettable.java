public interface Pettable {
    public void pet();
}
